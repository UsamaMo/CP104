"""
-------------------------------------------------------
[Lab 7,Task 4]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-05"
-------------------------------------------------------
"""
# import
from functions import sum_squares

# input
target = int(input("Please Enter an Integer Number:"))

# function
final = sum_squares(target)

# output
print(f"sum_squares({target}) -> {final}")
