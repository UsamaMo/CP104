"""
-------------------------------------------------------
[Lab 7, Task 7]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-05"
-------------------------------------------------------
"""
# import
from functions import meal_costs

# function
b_total, l_total, s_total, a_total = meal_costs()
