"""
-------------------------------------------------------
[Lab 7, Task 2]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-05"
-------------------------------------------------------
"""

# import
from functions import power_of_two

# input
target = int(input("Please Enter an Integer (Exponent): "))

# function
power = power_of_two(target)

# output
print(f'power_of_two({target}) -> {power}')
