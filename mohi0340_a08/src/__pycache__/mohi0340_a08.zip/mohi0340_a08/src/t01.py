"""
-------------------------------------------------------
[Assignment 8, Task 1]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-28"
-------------------------------------------------------
"""

# import
from functions import add_spaces

# input
string = input("Enter a sentence to add Spaces: ")

# function
new_string = add_spaces(string)

# output
print(new_string)
