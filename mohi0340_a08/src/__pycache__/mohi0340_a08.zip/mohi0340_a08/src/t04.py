"""
-------------------------------------------------------
[Assignment 8, Task 4]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-28"
-------------------------------------------------------
"""

# import
from functions import is_valid_isbn

# input
isbn = input("Enter isbn: ")

# function
valid = is_valid_isbn(isbn)

# output
print(valid)
