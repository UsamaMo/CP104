"""
-------------------------------------------------------
[Assignment 7, Task 2]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-22"
-------------------------------------------------------
"""

# import
from functions import list_positives

# function
numbers = list_positives()
