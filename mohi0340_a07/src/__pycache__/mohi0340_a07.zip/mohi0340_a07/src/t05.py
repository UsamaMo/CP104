"""
-------------------------------------------------------
[Assignment 7, Task 5]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-22"
-------------------------------------------------------
"""

# imports
from functions import is_sorted

# inputs
values = [3, 2, 1]

# function
in_order, index = is_sorted(values)

# output
print(f'{in_order}, {index}')
