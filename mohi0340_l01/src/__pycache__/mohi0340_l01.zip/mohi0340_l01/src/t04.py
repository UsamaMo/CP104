"""
-------------------------------------------------------
Lab 1, Task 4
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:      212090340
Email:   mohi0340@mylaurier.ca
__updated__ = "2021-09-13"
-------------------------------------------------------
"""
name = input("Please enter your name: ")
print("Pleased to meet you ")
print(name)
