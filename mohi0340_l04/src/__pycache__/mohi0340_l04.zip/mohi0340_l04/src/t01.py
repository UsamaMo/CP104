"""
-------------------------------------------------------
[Lab 4, Task 1]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-10-08"
-------------------------------------------------------
"""

# Import
from functions import diameter

# Input
radius = float(input("Enter Radius:"))

# function
diame = diameter(radius)

# Output
print(f"Diameter of Circle: {diame:.2f} ")
