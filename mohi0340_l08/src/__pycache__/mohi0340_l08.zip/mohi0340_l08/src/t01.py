"""
-------------------------------------------------------
[Lab 8, Task 1]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-12"
-------------------------------------------------------
"""
# import
from functions import get_weekday_name

# input
d = int(input("Enter an integer to represent days (1-7): "))

# function
name = get_weekday_name(d)

# output
print(name)
