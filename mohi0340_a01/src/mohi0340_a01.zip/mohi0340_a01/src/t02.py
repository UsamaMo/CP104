"""
-------------------------------------------------------
[Assignment 2, Task 2]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-09-22"
-------------------------------------------------------
"""

# variables
age = int(input("Enter your Age:"))
band = str(input("Enter your favourite band:"))

print("I am", age, "years old and my favourite band is", band)
