"""
-------------------------------------------------------
[Assignment 1, Task 3]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-09-22"
-------------------------------------------------------
"""
# constant
MKCONVERSION = 1.609

miles = float(input("Length in Miles:"))

# conversion formula
kilometres = miles * MKCONVERSION

print("Length in km:", kilometres)
