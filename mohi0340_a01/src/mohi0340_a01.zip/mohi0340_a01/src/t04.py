"""
-------------------------------------------------------
[Assignment 1, Task 4]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-09-22"
-------------------------------------------------------
"""

# variables
cost_one_burr = float(input("Cost of one burrito: $"))
num_burr = int(input("Number of burritos:"))

# formula
total_burr = cost_one_burr * num_burr

print("Total cost of", num_burr,  "burritos: $", total_burr)
