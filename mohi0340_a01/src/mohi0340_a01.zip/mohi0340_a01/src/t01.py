"""
-------------------------------------------------------
[Assignment 1, Task 1]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-09-25"
-------------------------------------------------------
"""


print('The book title is, "The Fifth Season"')
print("what's mine is mine, and what's yours is mine")
print('"Experience is one thing you can`t get for nothing".Oscar Wilde')
print(""" Three things cannot be long hidden:
    the sun,
    the moon, 
    and the truth. """)
