"""
-------------------------------------------------------
[Assignment 3, Task 5]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-10-18"
-------------------------------------------------------
"""
# import
from functions import math_quiz

# function
math_quiz()
