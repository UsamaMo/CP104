"""
-------------------------------------------------------
[Assignment 5, Task 2]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-08"
-------------------------------------------------------
"""

# import
from functions import calories_burned

# input
per_minute = 4.1
minutes = 30

# output
calories_burned(per_minute, minutes)
