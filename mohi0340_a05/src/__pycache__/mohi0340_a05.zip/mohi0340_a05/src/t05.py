"""
-------------------------------------------------------
[Assignment 5, Task 5]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-08"
-------------------------------------------------------
"""
# import
from functions import range_total

# input
start = 1
increment = 1
count = 5

# function
total = range_total(start, increment, count)

# output
print(f"range_total({start},{increment},{count}) -> {total}")
