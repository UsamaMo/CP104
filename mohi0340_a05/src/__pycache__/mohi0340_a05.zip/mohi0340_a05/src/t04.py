"""
-------------------------------------------------------
[Assignment 5, Task 4]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-08"
-------------------------------------------------------
"""
# import
from functions import multiplication_table

# input
start = 2
stop = 6

# output
multiplication_table(start, stop)
