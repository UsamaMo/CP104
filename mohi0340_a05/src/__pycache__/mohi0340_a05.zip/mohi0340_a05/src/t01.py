"""
-------------------------------------------------------
[Assignment 5, Task 1]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-08"
-------------------------------------------------------
"""

# import
from functions import factorial

# input
num = 1

# function
product = factorial(num)

# output
print(f"factorial({num})-> {product}")
