"""
-------------------------------------------------------
[Assignment 5, Task 3]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-08"
-------------------------------------------------------
"""
# import
from functions import open_triangle

# input
num_rows = 8

# output
open_triangle(num_rows)
