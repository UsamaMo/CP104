"""
-------------------------------------------------------
[Assignment 9 Task 1]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-12-05"
-------------------------------------------------------
"""

# import
from functions import file_head

# input
fh = open("functions.py", "r", encoding="utf-8")
linecount = 5

# function
file_head(fh, 5)
