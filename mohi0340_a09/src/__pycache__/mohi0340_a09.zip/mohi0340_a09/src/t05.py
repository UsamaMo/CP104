"""
-------------------------------------------------------
[Assignment 9 Task 5]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-12-05"
-------------------------------------------------------
"""

# import
from functions import matrix_rotate_right

# input
matrix = [[1, 2, 9, 8], [7, 12, 4, 2]]

# function
rotated = matrix_rotate_right(matrix)

# output
print(rotated)
