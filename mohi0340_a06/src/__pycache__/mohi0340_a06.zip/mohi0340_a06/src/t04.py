"""
-------------------------------------------------------
[Assignment 5, Task 4]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-15"
-------------------------------------------------------
"""

# Imports
from functions import digit_count

# input
num = int(input("Enter Number: "))

# function
count = digit_count(num)

# output
print(f"digit_count({num}) -> {count}")
