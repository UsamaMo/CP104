"""
-------------------------------------------------------
[Task 5]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-10-25"
-------------------------------------------------------
"""

# import
from functions import yee_ha

# input
number = int(input("Enter a number: "))

# functions
output = yee_ha(number)

# output
print(f'yee_ha({number}) -> "{output}"')
