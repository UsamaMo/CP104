"""
-------------------------------------------------------
[Lab 6, Task 9]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-10-29"
-------------------------------------------------------
"""
n = 99

# import
from functions import bottles_of_beer

# function
bottles_of_beer(n)
