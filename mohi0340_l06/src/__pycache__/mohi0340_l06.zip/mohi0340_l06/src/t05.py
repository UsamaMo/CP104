"""
-------------------------------------------------------
[Lab 6, Task 5]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-10-29"
-------------------------------------------------------
"""

# import
from functions import draw_rectangle

# input
height = int(input("Enter height in characters: "))
width = int(input("Enter width in characters: "))
char = input("Enter the draw character: ")

print()

# function
draw_rectangle(height, width, char)
