"""
-------------------------------------------------------
[Lab 3, Task 11]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-10-01"
-------------------------------------------------------
"""

# strings
location1 = "left"
location2 = "middle"
location3 = "right"

# print string variables
print(f"{location1:-<20}")
print(f"{location2:-^20}")
print(f"{location3:->20}")
