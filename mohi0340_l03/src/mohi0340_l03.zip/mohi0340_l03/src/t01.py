"""
-------------------------------------------------------
[Lab 3, Task 1]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-10-01"
-------------------------------------------------------
"""
# print paragraph
print("""'I'm a little astronaut' by Jean Warren

I'm a little astronaut
    Flying to the moon.
        My rocket is ready,
        We blast off soon.
I climb aboard
    And close the hatch.
        5-4-3-2-1, off we blast!""")
