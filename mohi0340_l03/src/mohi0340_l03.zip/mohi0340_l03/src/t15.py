"""
-------------------------------------------------------
[Lab 3, Task 15]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-10-01"
-------------------------------------------------------
"""

integer = 654321
decimal = 654.32
phrase = "Hello World"


print(f"Integer as an integer= {integer:d}")
print(f"Integer as a Floating Point(real number)= {integer:f}")
# print(f"Integer as a string= {integer:s}")


# print(f"Decimal as an integer= {decimal:d}")
print(f"Decimal as a Floating Point(real number)= {decimal:f}")
# print(f"Decimal as a string= {decimal:s}")


# print(f"Phrase as an integer= {phrase:d}")
# print(f"Phrase as a Floating Point(real number)= {phrase:f}")
print(f"Phrase as a string= {phrase:s}")
