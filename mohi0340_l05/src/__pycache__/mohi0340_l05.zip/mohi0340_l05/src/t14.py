"""
-------------------------------------------------------
[Lab 5, Task 14]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-10-22"
-------------------------------------------------------
"""

# import
from functions import ticket

# calculations
price = ticket()

# output
print(f"Price: ${price:.2f}")
