"""
-------------------------------------------------------
[Lab 11, Task 5]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-12-03"
-------------------------------------------------------
"""

# import
from functions import words_to_matrix

# input
word_list = ["cat", "dog", "big"]

# function
matrix = words_to_matrix(word_list)

# output
print(f"Strings: {word_list}")
print()
print("Matrix of characters:")
print()
print(matrix)
