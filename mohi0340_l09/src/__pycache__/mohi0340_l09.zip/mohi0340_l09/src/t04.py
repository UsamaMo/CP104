"""
-------------------------------------------------------
[Lab 9, Task 4]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-19"
-------------------------------------------------------
"""

# import
from functions import validate_code

# input
product_code = input(f"Enter a product code: ")

print()

# function
validate_code(product_code)
