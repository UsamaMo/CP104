"""
-------------------------------------------------------
[Lab 9, Task 5]
-------------------------------------------------------
Author:  Usama Mohiuddin
ID:           212090340
Email:     mohi0340@mylaurier.ca
__updated__ = "2021-11-19"
-------------------------------------------------------
"""
# import
from functions import password_strength

# input
password = input("Enter a password: ")


print()

# function
password_strength(password)
